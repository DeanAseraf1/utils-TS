export type childrenType = string | number | React.ReactElement<any, string | React.JSXElementConstructor<any>>;

// export type buttonRendererProps = React.FC<{
//     onClick:React.MouseEventHandler<HTMLButtonElement>
// }>

// export type buttonRendererProps = (props: {
//     onClick:React.MouseEventHandler<HTMLButtonElement>
// })=>JSX.Element;

// export type hiddenRendererProps = (props: {
//     className:string, 
//     children?: childrenType
// },
// closeButtonProps?: {
//     onClick:React.MouseEventHandler<HTMLButtonElement>, 
//     children?: childrenType
// })=>JSX.Element;


